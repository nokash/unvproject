<?php $__env->startSection('content'); ?>
<br><br>
<h1>This is Home Page</h1>
  <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>