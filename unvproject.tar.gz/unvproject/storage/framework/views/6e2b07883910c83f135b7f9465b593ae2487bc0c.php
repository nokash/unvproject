<?php $__env->startSection('content'); ?>
<br>

    <a href="/projects" class="btn btn-primary">Go Back</a>
    <h2><?php echo e($project->title); ?></h2>
    <div class="col-md-4 col-sm4">
        Status: <?php echo e($project->status); ?>

        <p> Duration: <?php echo e($project->months); ?> months</p>
        <p> Date From GCF: <?php echo e($project->gcf_date); ?></p>
    </div>
    <div class="col-md-6 col-sm4">
       <p> Project ID: <?php echo $project->project_id; ?> </p>
       <p> Country/Countries: <?php echo $project->countries; ?> </p>
    
        <p> First Disbursement: <?php echo $project->first_disbursement; ?> </p>
        <p> Office: <?php echo $project->name; ?> </p>
        <p> Total Cost: <?php echo $project->amount; ?> </p>

    <div>

        </div>
    <div>
        <p> Readiness: <?php echo $project->readiness_nap; ?> </p>
        <p> Readiness Type: <?php echo $project->readiness_type; ?> </p>
    </div>
    <hr>
<small>Started on: <?php echo e($project->start_date); ?> and Ends on:   <?php echo e($project->stop_date); ?></small>
    <hr>
    
    <br>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>