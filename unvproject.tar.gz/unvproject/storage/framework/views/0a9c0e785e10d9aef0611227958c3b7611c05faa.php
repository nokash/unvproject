<?php $__env->startSection('content'); ?>
<br><br>
<h1>Projects Section</h1>
  <br>
  <a href="/projects/create" class="btn btn-primary">Add Project</a> <br><br>
  <?php if(count($projects) > 0): ?>
  <table class="table table-striped">
      <?php echo Form::open([ 'action' =>['ProjectsController@index'], 'method' => 'get' ]); ?>

          <p><?php echo Form::select( 'per_page', [ '10' => '10', '15' => '15', '20' => '20', '50' => '50'], 'per_page', array('onchange' => "submit()") ); ?>

          </p>
      <?php echo Form::close(); ?>

      <tr>
          <th>Project Reference</th>
          <th>Status</th>
          <th>Action</th>
      </tr>
      
      <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td><?php echo e($project->project_id); ?></td>
              <td><?php echo e($project->status); ?></td>
              <td><a href="/projects/<?php echo e($project->id); ?>/" class="btn btn-primary">View</a>
                <a href="/projects/<?php echo e($project->id); ?>/edit" class="btn btn-primary">Edit</a>
              
              
                  <?php echo Form::open(['action' => ['ProjectsController@destroy', $project->id], 'method' => 'POST', 'class' => 'float-right']); ?>

                      <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                      <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                  <?php echo Form::close(); ?>

              </td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php echo e($projects->links()); ?>

  <?php else: ?>
  <p> You've got no posts!! </p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>