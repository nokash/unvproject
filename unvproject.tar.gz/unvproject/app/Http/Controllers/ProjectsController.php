<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Project;
use App\Country;
use App\Office;
use App\ProjectCountry;
use DB;

class ProjectsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
       
        
        
        // $squery = "SELECT projects.*, project_countries.project_id,  GROUP_CONCAT(countries.name SEPARATOR ',') as countries 
        // FROM projects INNER JOIN project_countries ON projects.project_id = project_countries.project_id 
        // INNER JOIN countries ON project_countries.country_id = countries.id GROUP BY project_countries.project_id ORDER BY project_countries.project_id DESC";
        $projects = DB::table('projects')
        ->select("projects.*", "project_countries.project_id",
            DB::raw("(GROUP_CONCAT(countries.name SEPARATOR ',')) as 'countries'"))
        ->join('project_countries', 'projects.project_id', '=', 'project_countries.project_id')
        ->join('countries', 'project_countries.country_id', '=', 'countries.id')
        ->groupBy('project_countries.project_id')
        ->orderBy('project_countries.project_id')
        ->paginate($request->get('per_page', 10));
        //$projects = DB::select(DB::raw($squery));
       
                        
        return view('projects.index',['projects'=>$projects]);
     
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $nations =  Country::all();
        foreach($nations as $nation){
            $selectedTags[] = $nation->id;

        }

        return view('projects.create')->with('nations')->with('selectedTags');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'title' => 'required',
            'amount' => 'required',
            'project_id' => 'required',
            'start_date' => 'required',
            'end_date' => 'required | date | after_or_equal:start_date',
            'gcf_date' => 'gcf_date',
            'readiness_nap' => 'required',
            'status' => 'required',
            'first_disbursement' => 'required',
            'gcf_date' => 'required',
            //'readiness_type' => 'required'
            
        ]);
        //
        $country = $request->input('countries');
        
        

        $project = new Project;
        
        $project->office_id = $request->input('office');
        $project->title = $request->input('title');
        $project->amount = $request->input('amount');
        $project->start_date = $request->input('start_date');
        $project->stop_date = $request->input('end_date');
        $project->readiness_nap = $request->input('readiness_nap');
        $project->readiness_type = $request->input('readiness_type');
        $project->status = $request->input('status');
        $project->gcf_date = $request->input('gcf_date');
        $project->first_disbursement = $request->input('first_disbursement');
        $project->project_id = $request->input('project_id');
        

        foreach($country as $country){
            $country_p = new ProjectCountry;
            $country_p->project_id = $request->input('project_id');
            $country_p->country_id = $country;
            $country_p->save();
        }
        $project->save();
        
        

        return redirect('/projects')->with('success', 'Project Added Successfuly');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $project = Project::find($id);
        $projects = DB::table('projects')
        ->select("projects.*", "project_countries.project_id", "offices.name",
            DB::raw("(TIMESTAMPDIFF(MONTH, start_date, stop_date)) as 'months'")  
            ,DB::raw("(GROUP_CONCAT(countries.name SEPARATOR ',')) as 'countries'"))
        ->join('project_countries', 'projects.project_id', '=', 'project_countries.project_id')
        ->join('countries', 'project_countries.country_id', '=', 'countries.id')
        ->join('offices', 'projects.office_id', '=', 'offices.id')
        ->groupBy('project_countries.project_id')
        ->where('projects.id', $id)
        ->first();

     
        return view('projects.show')->with(['project'=> $projects]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $project = Project::find($id);
       //$country_p = ProjectCountry::find($id);
    
        return view('projects.edit')->with('project', $project);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $country = $request->input('countries');

        $this->validate($request, [
            'title' => 'required',
            'amount' => 'required',
            'project_id' => 'required',
            'start_date' => 'required',
            'stop_date' => 'required',
            'readiness_nap' => 'required',
            'status' => 'required',
            'gcf_date' => 'gcf_date',
            'first_disbursement' => 'required',
            'gcf_date' => 'required',
            'readiness_type' => 'required'
            
        ]);
        //
      

        $project = Project::find($id);
        $project->office_id = $request->input('office');
        $project->title = $request->input('title');
        $project->amount = $request->input('amount');
        $project->start_date = $request->input('start_date');
        $project->stop_date = $request->input('stop_date');
        $project->readiness_nap = $request->input('readiness_nap');
        $project->readiness_type = $request->input('readiness_type');
        $project->status = $request->input('status');
        $project->gcf_date = $request->input('gcf_date');
        $project->first_disbursement = $request->input('first_disbursement');
        $project->project_id = $request->input('project_id');
        
        // foreach($country as $country){
        //     $country_p = new ProjectCountry;
        //     $country_p->project_id = $request->input('project_id');
        //     $country_p->country_id = $country;
        //     $country_p->save();
        // }
     
        $project->save();
        

        return redirect('/projects')->with('success', 'Project Edited Successfully');
    }

    /**body
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($project_id)
    {
        
        $project = Project::findorFail($project_id);
        $proj_c = ProjectCountry::where('project_id',$project->project_id)->first();
        $project->delete();
        $proj_c->delete();
        return redirect('/projects')->with('success', 'Post Deleted Successfully');
    
    }
}
