<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Project;
use App\ProjectCountry;
use App\Country;
use Eloquent;
use DB;

class APIController extends Controller
{
    //
    public function __construct()
    {
        
    }
    
    public function projects()
    {
        //JSON for all
        //$projects = Project::all();
        $projects = DB::table('projects')
                        ->join('project_countries', 'projects.project_id', '=','project_countries.project_id')
                        ->join('countries', 'countries.id', '=', 'project_countries.country_id')
                        ->join('offices', 'offices.id', '=', 'projects.office_id')
                        ->select('projects.*', 'countries.name', 'offices.name')
                        ->get();
        return view('projects.api')->with('projects', $projects);
    }

    public function country(Request $request, $country)
    {
        //JSON for Country
        $projects = DB::table('projects')
                        ->join('project_countries', 'projects.project_id', '=','project_countries.project_id')
                        ->join('countries', 'countries.id', '=', 'project_countries.country_id')
                        ->join('offices', 'offices.id', '=', 'projects.office_id')
                        ->select('projects.*', 'countries.name', 'offices.name')
                        ->where('countries.name', $country)
                        ->get();
        return view('projects.api')->with('projects', $projects);
    }

    public function projectStatus(Request $request, $status)
    {
        //JSON for status
        $projects =  Project::where('status', $status)->get();
        return view('projects.api')->with('projects', $projects);
    }
}
//SELECT project_countries.project_id, project_countries.country_id, countries.name FROM project_countries INNER JOIN countries ON project_countries.country_id = countries.id GROUP BY project_countries.id, project_countries.country_id ORDER BY project_countries.project_id DESC