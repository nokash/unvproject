@extends('layouts.base')

@section('content')
<br>

    <a href="/projects" class="btn btn-primary">Go Back</a>
    <h2>{{$project->title}}</h2>
    <div class="col-md-4 col-sm4">
        Status: {{$project->status}}
        <p> Duration: {{$project->months}} months</p>
        <p> Date From GCF: {{$project->gcf_date}}</p>
    </div>
    <div class="col-md-6 col-sm4">
       <p> Project ID: {!!$project->project_id!!} </p>
       <p> Country/Countries: {!!$project->countries!!} </p>
    
        <p> First Disbursement: {!!$project->first_disbursement!!} </p>
        <p> Office: {!!$project->name!!} </p>
        <p> Total Cost: {!!$project->amount!!} </p>

    <div>

        </div>
    <div>
        <p> Readiness: {!!$project->readiness_nap!!} </p>
        <p> Readiness Type: {!!$project->readiness_type!!} </p>
    </div>
    <hr>
<small>Started on: {{$project->start_date}} and Ends on:   {{$project->stop_date}}</small>
    <hr>
    
    <br>
    <br>
@endsection