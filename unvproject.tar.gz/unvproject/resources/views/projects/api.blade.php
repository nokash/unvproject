@extends('layouts.base')

@section('content')
<br><br>
<h1>This is APIs Page</h1>
  <br><br>
  <p>{{$projects}}</p>
@endsection
