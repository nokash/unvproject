@extends('layouts.base')

@section('content')
<br><br>
<h1>This is Home Page</h1>
  <br><br>
@endsection
