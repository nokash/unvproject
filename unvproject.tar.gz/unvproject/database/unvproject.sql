-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Feb 27, 2019 at 11:30 PM
-- Server version: 5.7.24
-- PHP Version: 7.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unvproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `continent` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `continent`) VALUES
(1, 'Kenya', 'Africa'),
(2, 'Uganda', 'Africa'),
(3, 'Commoros', 'Africa'),
(4, 'Tanzania', 'Africa'),
(5, 'Brazil', 'South America'),
(6, 'Panama', 'South America'),
(7, 'Albania', 'Europe'),
(8, 'Romania\r\n', 'Europe'),
(9, 'Costa Rica', 'South America'),
(10, 'Dominican Republic', 'South America'),
(11, 'Egypt', 'Africa'),
(12, 'Morocco', 'Africa'),
(13, 'Sudan', 'Africa'),
(14, 'Honduras', 'South America'),
(15, 'Jordan', 'Asia'),
(16, 'Madagascar', 'Africa'),
(17, 'Malaysia', 'Asia'),
(18, 'Maldives', 'Asia'),
(19, 'Mauritania', 'Africa'),
(20, 'Mauritius', 'Africa'),
(21, 'Mongolia', 'Asia'),
(22, 'Montenegro', 'Europe'),
(23, 'Myanmar', 'Asia'),
(24, 'Nepal', 'Asia'),
(25, 'Niger', 'Africa'),
(26, 'Pakistan', 'Asia'),
(27, 'Palestine', 'Asia'),
(28, 'Serbia', 'Europe'),
(29, 'South Sudan', 'Africa'),
(31, 'Swaziland', 'Africa'),
(32, 'Tonga', 'Asia'),
(33, 'Zimbabwe', 'Africa'),
(34, 'Jordan PPFA', ''),
(35, 'Ghana', 'Africa');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_02_23_100512_create_projects_table', 2),
(4, '2019_02_23_100609_create_project_countries_table', 2),
(5, '2019_02_23_100648_create_offices_table', 2),
(6, '2019_02_23_100715_create_countries_table', 2),
(7, '2019_02_23_143749_add_gcf_date_to_project_countries_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `offices`
--

CREATE TABLE `offices` (
  `id` int(10) UNSIGNED NOT NULL,
  `country_id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `offices`
--

INSERT INTO `offices` (`id`, `country_id`, `name`) VALUES
(1, 1, 'Europe Office'),
(2, 2, 'Economy Division'),
(3, 6, 'Latin America Office'),
(4, 2, 'Ecosystems'),
(5, 3, 'CTCN'),
(6, 4, 'West Asia Office'),
(7, 7, 'Asia Pacific Office'),
(8, 1, 'Africa Office'),
(10, 8, 'Policy & Programme Division');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `office_id` int(11) NOT NULL,
  `title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `gcf_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `start_date` datetime NOT NULL,
  `stop_date` datetime NOT NULL,
  `readiness_nap` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `readiness_type` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_disbursement` int(11) NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `project_id`, `office_id`, `title`, `amount`, `gcf_date`, `start_date`, `stop_date`, `readiness_nap`, `readiness_type`, `first_disbursement`, `status`, `created_at`, `updated_at`) VALUES
(73, 'ALB-RS-001', 1, 'Readiness support to Albania', 300000, '2019-02-28 00:00:00', '2019-02-28 00:00:00', '2019-02-28 00:00:00', 'Readiness', 'Capacity Building', 147500, 'Completed', '2019-02-28 05:34:56', '2019-02-28 02:34:56'),
(74, 'BRA-RS-001', 2, 'Technology Needs Assessment for the Implementation of Climate Action Plans', 700000, '2018-06-20 00:00:00', '2018-06-20 00:00:00', '2019-12-19 00:00:00', 'Readiness', 'FI/TNA/other', 197450, 'under implementation', '2019-02-27 13:21:35', '2019-02-27 13:21:35'),
(75, 'COM-RS-001', 4, '1. Establishing and strengthening National Designated Authorities or Focal Points; 2. Developing strategic frameworks for engagement with the GCF, including the preparation of country programmes.', 426080, '2018-11-01 00:00:00', '2018-11-01 00:00:00', '2020-10-21 00:00:00', 'Readiness', 'Capacity Building', 115117, 'under implementation', '2019-02-27 13:24:21', '2019-02-27 13:24:21'),
(76, 'CRI-RS-002', 3, 'Building sub-national capacities for the implementation of the National Adaptation Plan in Costa Rica', 2861917, '2018-10-23 00:00:00', '2018-10-23 00:00:00', '2021-10-23 00:00:00', 'NAP', 'NAP', 350575, 'under implementation', '2019-02-27 13:28:30', '2019-02-27 13:28:30'),
(77, 'DOM-RS-002', 3, 'Building capacity to advance National Adaptation Plan Process in the Dominican Republic', 2998325, '2018-07-11 00:00:00', '2018-07-11 00:00:00', '2021-06-10 00:00:00', 'NAP', 'NAP', 2998325, 'under implementation', '2019-02-27 14:15:25', '2019-02-27 14:15:25'),
(78, 'EGY-RS-001', 4, 'Supporting Egypt’s engagement with the Green Climate Fund: Logical framework support', 300000, '2017-05-02 00:00:00', '2017-04-24 00:00:00', '2018-10-23 00:00:00', 'Readiness', 'Capacity Building', 122456, 'under implementation', '2019-02-27 14:18:02', '2019-02-27 14:18:02'),
(79, 'GHA-RS-001', 5, 'Drought Early Warning and Forecasting System: Improving resiliency of crops to drought through strengthened early warning within Ghana, Uganda and Sudan', 300150, '2017-05-15 00:00:00', '2017-05-15 00:00:00', '2019-05-10 00:00:00', 'Readiness', 'FI/TNA/other', 300150, 'completion report submitted', '2019-02-27 16:04:48', '2019-02-27 16:04:48'),
(80, 'HND-RS-002', 1, 'Supporting strategic planning to engage with the GCF and comply with the national commitments under the Paris Agreement regarding the LULUCF sector', 764960, '2018-01-18 00:00:00', '2018-01-18 00:00:00', '2019-07-19 00:00:00', 'Readiness', 'REDD+', 243515, 'under implementation', '2019-02-27 19:13:12', '2019-02-27 16:13:12'),
(81, 'JOR-RS-001', 6, 'Strengthening NDA of Jordan to deliver on GCF Investment Framework', 300000, '2017-06-15 00:00:00', '2017-06-15 00:00:00', '2018-12-14 00:00:00', 'Readiness', 'Capacity Building', 150000, 'under implementation', '2019-02-27 16:11:08', '2019-02-27 16:11:08'),
(82, 'MDG-RS-001', 4, 'Building Capacity in Madagascar to engage with the GCF', 300000, '2018-07-20 00:00:00', '2018-07-20 00:00:00', '2019-07-19 00:00:00', 'Readiness', 'Capacity Building', 177588, 'under implementation', '2019-02-27 16:15:14', '2019-02-27 16:15:14'),
(83, 'MLY-RS-002', 7, 'Accessing REDD+ result-based payments in Malaysia', 819230, '2018-11-12 00:00:00', '2018-11-12 00:00:00', '2020-11-13 00:00:00', 'Readiness', 'REDD+', 465695, 'under implementation', '2019-02-27 16:18:25', '2019-02-27 16:18:25'),
(84, 'MDV-RS-001', 7, 'Establishing and strengthening National Designated Authority (NDA), and developing strategic framework for engagement with the GCF in Maldives', 300000, '2017-06-16 00:00:00', '2017-06-16 00:00:00', '2018-06-13 00:00:00', 'Readiness', 'Capacity Building', 198545, 'under implementation', '2019-02-27 16:21:05', '2019-02-27 16:21:05'),
(85, 'MRT-RS-002', 8, 'Building capacity to advance National Adaptation Plan Process in Mauritania', 2670374, '2018-07-17 00:00:00', '2018-07-17 00:00:00', '2021-07-08 00:00:00', 'NAP', 'NAP', 742163, 'under implementation', '2019-02-27 16:23:22', '2019-02-27 16:23:22'),
(86, 'MUS-RS-002', 5, 'Climate Change Vulnerability and Adaptation Study for Port of Port Louis', 324764, '2018-01-22 00:00:00', '2018-01-22 00:00:00', '2019-04-19 00:00:00', 'Readiness', 'FI/TNA/other', 324764, 'under implementation', '2019-02-27 16:25:35', '2019-02-27 16:25:35'),
(87, 'MNG-RS-003', 7, 'Scaling-up of Implementation of Low-Carbon District Heating Systems in Mongolia', 368000, '2018-02-01 00:00:00', '2019-01-02 00:00:00', '2019-02-01 00:00:00', 'Readiness', 'FI/TNA/other', 250000, 'under implementation', '2019-02-27 16:27:51', '2019-02-27 16:27:51'),
(88, 'MNG-RS-004', 7, 'Building capacity to advance National Adaptation Plan Process in Mongolia', 2895461, '2018-06-20 00:00:00', '2018-06-20 00:00:00', '2021-06-19 00:00:00', 'NAP', 'NAP', 406123, 'under implementation', '2019-02-27 16:30:38', '2019-02-27 16:30:38'),
(89, 'MNE-RS-001', 1, '1. Establishing and strengthening National Designated Authorities or Focal Points; 2. Developing strategic frameworks for engagement with the GCF, including the preparation of country programmes.', 300000, '2016-11-15 00:00:00', '2016-08-30 00:00:00', '2017-08-30 00:00:00', 'Readiness', 'Capacity Building', 145300, 'under implementation', '2019-02-27 16:33:06', '2019-02-27 16:33:06'),
(90, 'MMR-RS-002', 7, 'Establishing and Strengthening National Designated Authority (NDA), and Developing Strategic Framework for Engagement with the GCF in Myanmar', 300000, '2017-11-10 00:00:00', '2017-10-11 00:00:00', '2019-05-11 00:00:00', 'Readiness', 'Capacity Building', 115840, 'under implementation', '2019-02-27 16:35:16', '2019-02-27 16:35:16'),
(91, 'MMR-RS-001', 5, 'Strengthened drought and flood management through improved science‐based information availability and management in Myanmar', 336520, '2017-07-26 00:00:00', '2017-07-26 00:00:00', '2018-07-26 00:00:00', 'Readiness', 'FI/TNA/other', 336520, 'under implementation', '2019-02-27 16:37:14', '2019-02-27 16:37:14'),
(92, 'NPL-RS-001', 7, 'Building Capacity to Advance National Adaptation Plan Process in Nepal', 2935350, '2017-05-15 00:00:00', '2017-05-15 00:00:00', '2020-05-14 00:00:00', 'NAP', 'NAP', 465410, 'under implementation', '2019-02-27 16:39:13', '2019-02-27 16:39:13'),
(93, 'NER-RS-002', 4, 'Building Niger’s engagement with the GCF: Establishment and strengthening of the NDA, and elaboration of a country programme identifying strategic priorities', 300000, '2018-06-20 00:00:00', '2018-06-20 00:00:00', '2019-12-19 00:00:00', 'Readiness', 'Capacity Building', 138100, 'Requesting Funds', '2019-02-27 16:41:17', '2019-02-27 16:41:17'),
(94, 'PAK-RS-003', 7, 'Building capacity to advance National Adaptation Plan Process in Pakistan', 2969674, '2018-03-02 00:00:00', '2018-03-03 00:00:00', '2021-03-04 00:00:00', 'NAP', 'NAP', 675420, 'under implementation', '2019-02-27 16:43:17', '2019-02-27 16:43:17'),
(95, 'PSE-RS-002', 5, 'Technology Road Map for the Implementation of Climate Action Plans in Palestine.', 254100, '2017-10-18 00:00:00', '2017-10-18 00:00:00', '2018-10-18 00:00:00', 'Readiness', 'FI/TNA/other', 254100, 'under implementation', '2019-02-27 16:45:19', '2019-02-27 16:45:19'),
(96, 'SRB-RS-001', 1, 'Developing the capacities of the Republic of Serbia for an effective engagement with the Green Climate Fund', 300000, '2018-01-12 00:00:00', '2018-01-12 00:00:00', '2019-01-12 00:00:00', 'Readiness', 'Capacity Building', 130000, 'under implementation', '2019-02-27 16:47:12', '2019-02-27 16:47:12'),
(97, 'SSD-RS-001', 10, 'Republic of South Sudan Green Climate Fund’s Readiness and Preparatory Support Project', 300000, '2018-06-20 00:00:00', '2018-06-20 00:00:00', '2019-12-19 00:00:00', 'Readiness', 'Capacity Building', 153178, 'under implementation', '2019-02-27 16:49:26', '2019-02-27 16:49:26'),
(98, 'SWZ-RS-002', 4, 'Green Climate Fund Readiness Support for Swaziland', 299032, '2018-03-12 00:00:00', '2018-03-12 00:00:00', '2020-03-13 00:00:00', 'Readiness', 'Capacity Building', 83046, 'under implementation', '2019-02-27 16:51:26', '2019-02-27 16:51:26'),
(99, 'SWZ-RS-003', 8, 'Building capacity to advance National Adaptation Plan process in Swaziland', 2796359, '2018-06-28 00:00:00', '2018-06-28 00:00:00', '2021-02-27 00:00:00', 'NAP', 'NAP', 744662, 'under implementation', '2019-02-27 16:53:59', '2019-02-27 16:53:59'),
(100, 'TON-RS-002', 5, 'To develop an energy efficiency master plan for the Kingdom of Tonga and East Africa', 200000, '2017-04-20 00:00:00', '2017-04-20 00:00:00', '2017-10-09 00:00:00', 'Readiness', 'FI/TNA/other', 200000, 'under implementation', '2019-02-27 16:56:21', '2019-02-27 16:56:21'),
(101, 'ZWE-RS-001', 4, '1. Establishing and strengthening National Designated Authorities or Focal Points; 2. Developing strategic frameworks for engagement with the GCF, including the preparation of country programmes.', 300000, '2018-03-05 00:00:00', '2018-03-05 00:00:00', '2020-03-04 00:00:00', 'Readiness', 'Capacity Building', 121354, 'under implementation', '2019-02-27 16:58:09', '2019-02-27 16:58:09'),
(102, 'ZWE-RS-002', 8, 'Building capacity to advance National Adaptation Plan Process in Zimbabwe', 2993349, '2018-05-11 00:00:00', '2018-05-11 00:00:00', '2021-05-13 00:00:00', 'NAP', 'NAP', 877525, 'under implementation', '2019-02-27 17:00:38', '2019-02-27 17:00:38'),
(103, 'S1-32GCL-000023', 4, 'Jordan Integrated Landscape Management Initiative (JILMI)', 2886275, '2018-03-05 00:00:00', '2018-08-28 00:00:00', '2019-12-28 00:00:00', 'Readiness', NULL, 278946, 'under implementation', '2019-02-27 17:06:43', '2019-02-27 17:06:43'),
(104, 'JOR-RS-007', 1, 'Title Three', 100000000, '2019-02-28 00:00:00', '2019-02-28 00:00:00', '2019-02-28 00:00:00', 'Readiness', 'REDD+', 350575, 'Completed', '2019-02-28 04:26:36', '2019-02-28 04:26:36');

-- --------------------------------------------------------

--
-- Table structure for table `project_countries`
--

CREATE TABLE `project_countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_countries`
--

INSERT INTO `project_countries` (`id`, `project_id`, `country_id`, `created_at`, `updated_at`) VALUES
(85, 'ALB-RS-001', 7, '2019-02-27 16:18:13', '2019-02-27 16:18:13'),
(86, 'ALB-RS-001', 8, '2019-02-27 16:18:14', '2019-02-27 16:18:14'),
(87, 'BRA-RS-001', 5, '2019-02-27 16:21:34', '2019-02-27 16:21:34'),
(88, 'BRA-RS-001', 6, '2019-02-27 16:21:35', '2019-02-27 16:21:35'),
(89, 'COM-RS-001', 3, '2019-02-27 16:24:21', '2019-02-27 16:24:21'),
(90, 'CRI-RS-002', 9, '2019-02-27 16:28:30', '2019-02-27 16:28:30'),
(91, 'DOM-RS-002', 10, '2019-02-27 17:15:25', '2019-02-27 17:15:25'),
(92, 'EGY-RS-001', 11, '2019-02-27 17:18:02', '2019-02-27 17:18:02'),
(93, 'EGY-RS-001', 12, '2019-02-27 17:18:02', '2019-02-27 17:18:02'),
(94, 'GHA-RS-001', 2, '2019-02-27 19:04:48', '2019-02-27 19:04:48'),
(95, 'GHA-RS-001', 13, '2019-02-27 19:04:48', '2019-02-27 19:04:48'),
(96, 'GHA-RS-001', 35, '2019-02-27 19:04:48', '2019-02-27 19:04:48'),
(97, 'HND-RS-002', 14, '2019-02-27 19:07:19', '2019-02-27 19:07:19'),
(98, 'JOR-RS-001', 15, '2019-02-27 19:11:08', '2019-02-27 19:11:08'),
(99, 'MDG-RS-001', 16, '2019-02-27 19:15:14', '2019-02-27 19:15:14'),
(100, 'MLY-RS-002', 17, '2019-02-27 19:18:25', '2019-02-27 19:18:25'),
(101, 'MDV-RS-001', 18, '2019-02-27 19:21:04', '2019-02-27 19:21:04'),
(102, 'MRT-RS-002', 19, '2019-02-27 19:23:22', '2019-02-27 19:23:22'),
(103, 'MUS-RS-002', 20, '2019-02-27 19:25:34', '2019-02-27 19:25:34'),
(104, 'MNG-RS-003', 21, '2019-02-27 19:27:51', '2019-02-27 19:27:51'),
(105, 'MNG-RS-004', 21, '2019-02-27 19:30:38', '2019-02-27 19:30:38'),
(106, 'MNE-RS-001', 22, '2019-02-27 19:33:06', '2019-02-27 19:33:06'),
(107, 'MMR-RS-002', 23, '2019-02-27 19:35:16', '2019-02-27 19:35:16'),
(108, 'MMR-RS-001', 23, '2019-02-27 19:37:14', '2019-02-27 19:37:14'),
(109, 'NPL-RS-001', 24, '2019-02-27 19:39:13', '2019-02-27 19:39:13'),
(110, 'NER-RS-002', 25, '2019-02-27 19:41:17', '2019-02-27 19:41:17'),
(111, 'PAK-RS-003', 26, '2019-02-27 19:43:17', '2019-02-27 19:43:17'),
(112, 'PSE-RS-002', 27, '2019-02-27 19:45:19', '2019-02-27 19:45:19'),
(113, 'SRB-RS-001', 28, '2019-02-27 19:47:12', '2019-02-27 19:47:12'),
(114, 'SSD-RS-001', 11, '2019-02-27 19:49:26', '2019-02-27 19:49:26'),
(115, 'SSD-RS-001', 29, '2019-02-27 19:49:26', '2019-02-27 19:49:26'),
(116, 'SWZ-RS-002', 31, '2019-02-27 19:51:26', '2019-02-27 19:51:26'),
(117, 'SWZ-RS-003', 31, '2019-02-27 19:53:59', '2019-02-27 19:53:59'),
(118, 'TON-RS-002', 1, '2019-02-27 19:56:21', '2019-02-27 19:56:21'),
(119, 'TON-RS-002', 2, '2019-02-27 19:56:21', '2019-02-27 19:56:21'),
(120, 'TON-RS-002', 4, '2019-02-27 19:56:21', '2019-02-27 19:56:21'),
(121, 'TON-RS-002', 32, '2019-02-27 19:56:21', '2019-02-27 19:56:21'),
(122, 'ZWE-RS-001', 33, '2019-02-27 19:58:09', '2019-02-27 19:58:09'),
(123, 'ZWE-RS-002', 33, '2019-02-27 20:00:05', '2019-02-27 20:00:05'),
(124, 'ZWE-RS-002', 33, '2019-02-27 20:00:38', '2019-02-27 20:00:38'),
(125, 'S1-32GCL-000023', 34, '2019-02-27 20:06:42', '2019-02-27 20:06:42'),
(126, 'JOR-RS-007', 1, '2019-02-28 07:26:36', '2019-02-28 07:26:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Ashford Musya Ngui', 'ashfordnokash@gmail.com', NULL, '$2y$10$F15PbMyKCibpbfi5lxc4r.OuSxkNOuz6y4oU2ZgCjk.K0FZDhJ6xi', 'TfvaZYAAxM3D8LH6LnhbPaYudrW7W9IY8fFnsr4xy3v6ru3nNwH4LO53Sk62', '2019-02-23 15:47:42', '2019-02-23 15:47:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offices`
--
ALTER TABLE `offices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_id_2` (`project_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `project_countries`
--
ALTER TABLE `project_countries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `offices`
--
ALTER TABLE `offices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `project_countries`
--
ALTER TABLE `project_countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
